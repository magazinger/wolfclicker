"""Сервер Wolf Clicker. Только стандартная библиотека Python, ничего устанавливать не нужно.
Работает как WSGI-приложение (PythonAnywhere) и как обычный скрипт (python wolf_server.py)."""
import hashlib
import hmac
import json
import os
import random
import sqlite3
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

BOT_TOKEN = "9034675741:AAH7Lsu_WWUDkzD0m6c7QiN9FfnjmMURe58"

# ---- Настройки игры ----
BASE_ENERGY = 500        # стартовый лимит энергии
ENERGY_STEP = 100        # +к лимиту за уровень улучшения
REGEN = 1.0              # базовое восстановление энергии в секунду
REGEN_STEP = 1.0         # +к скорости восстановления за уровень улучшения
LUCKY_CHANCE = 0.01      # шанс редкого клика на каждый клик (1%)
LUCKY_BONUS = 500        # бонус за редкий клик
MAX_BATCH = 200          # максимум кликов в одном запросе
TASK_BUY_GOAL = 3        # купить улучшений за день
TASK_EARN_GOAL = 1000    # заработать монет кликами за день
TASK_REWARD = 10000      # награда за каждое задание
CHANNEL = "@wolfclik"    # канал, подписка на который проверяется (бот должен быть админом канала)
LOGIN_STEP = 10000       # бонус за вход: день 1 = 10000, день 2 = 20000 ... день 10 = 100000, потом сначала
LOGIN_DAYS = 10
SKINS = [                # id, название, цена
    ("default", "Классика", 0),
    ("golden", "Golden", 200000),
    ("valentine", "Valentine", 300000),
    ("white_wolf", "White Wolf", 500000),
]
SKIN_PRICE = {k: p for k, _, p in SKINS}
RESET_HOUR_MSK = 0       # во сколько по Москве обновляются задания (0 = полночь)

MSK = timezone(timedelta(hours=3))
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wolf.db")
LOCK = threading.Lock()


def db():
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, name TEXT, coins INTEGER DEFAULT 0, total INTEGER DEFAULT 0,
        tap_lvl INTEGER DEFAULT 0, en_lvl INTEGER DEFAULT 0, energy REAL DEFAULT 500, ts REAL,
        day TEXT, bought INTEGER DEFAULT 0, earned INTEGER DEFAULT 0, c1 INTEGER DEFAULT 0, c2 INTEGER DEFAULT 0, regen_lvl INTEGER DEFAULT 0)""")
    for col in ("regen_lvl INTEGER DEFAULT 0", "skin TEXT DEFAULT 'default'", "skins TEXT DEFAULT 'default'",
                "sub INTEGER DEFAULT 0", "streak INTEGER DEFAULT 0", "last_claim TEXT DEFAULT ''"):
        try:
            c.execute("ALTER TABLE users ADD COLUMN " + col)  # добавляет новые поля в старую базу
        except sqlite3.OperationalError:
            pass
    return c


def cost(level):
    return int(100 * 1.6 ** level)


def regen_rate(u):
    return REGEN + REGEN_STEP * u["regen_lvl"]


def max_energy(u):
    return BASE_ENERGY + ENERGY_STEP * u["en_lvl"]


def day_key():
    return (datetime.now(MSK) - timedelta(hours=RESET_HOUR_MSK)).strftime("%Y-%m-%d")


def reset_in():
    now = datetime.now(MSK)
    start = (now - timedelta(hours=RESET_HOUR_MSK)).replace(hour=0, minute=0, second=0, microsecond=0)
    nxt = start + timedelta(days=1, hours=RESET_HOUR_MSK)
    return int((nxt - now).total_seconds())


def check_init(init_data):
    """Проверяет подпись Telegram и возвращает данные пользователя или None."""
    try:
        d = dict(urllib.parse.parse_qsl(init_data, keep_blank_values=True))
        h = d.pop("hash")
        s = "\n".join(k + "=" + v for k, v in sorted(d.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, s.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc, h):
            return None
        if time.time() - int(d.get("auth_date", "0")) > 3 * 86400:
            return None
        return json.loads(d["user"])
    except Exception:
        return None


def load(c, tg_user):
    now = time.time()
    row = c.execute("SELECT * FROM users WHERE id=?", (tg_user["id"],)).fetchone()
    name = tg_user.get("first_name") or tg_user.get("username") or "Игрок"
    if row is None:
        c.execute("INSERT INTO users(id,name,energy,ts,day) VALUES(?,?,?,?,?)",
                  (tg_user["id"], name, BASE_ENERGY, now, day_key()))
        row = c.execute("SELECT * FROM users WHERE id=?", (tg_user["id"],)).fetchone()
    u = dict(row)
    u["name"] = name
    u["energy"] = min(max_energy(u), u["energy"] + (now - u["ts"]) * regen_rate(u))
    u["ts"] = now
    if u["day"] != day_key():
        u.update(day=day_key(), bought=0, earned=0, c1=0, c2=0)
    return u


def save(c, u):
    c.execute("""UPDATE users SET name=?,coins=?,total=?,tap_lvl=?,en_lvl=?,energy=?,ts=?,day=?,
                 bought=?,earned=?,c1=?,c2=?,regen_lvl=?,skin=?,skins=?,sub=?,streak=?,last_claim=? WHERE id=?""",
              (u["name"], u["coins"], u["total"], u["tap_lvl"], u["en_lvl"], u["energy"], u["ts"], u["day"],
               u["bought"], u["earned"], u["c1"], u["c2"], u["regen_lvl"], u["skin"],
               u["skins"], u["sub"], u["streak"], u["last_claim"], u["id"]))
    c.commit()


def login_info(u):
    today = day_key()
    if u["last_claim"] == today:
        return {"claimed": True, "day": u["streak"]}
    yesterday = (datetime.strptime(today, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
    day = (u["streak"] % LOGIN_DAYS) + 1 if u["last_claim"] == yesterday else 1
    return {"claimed": False, "day": day}


def is_subscribed(uid):
    """True/False, или None если проверить не удалось (например, бот не админ канала)."""
    try:
        url = ("https://api.telegram.org/bot" + BOT_TOKEN + "/getChatMember?chat_id=" +
               urllib.parse.quote(CHANNEL) + "&user_id=" + str(uid))
        with urllib.request.urlopen(url, timeout=10) as r:
            d = json.load(r)
        return bool(d.get("ok")) and d["result"]["status"] in ("creator", "administrator", "member")
    except Exception:
        return None


def state(u):
    return {
        "coins": u["coins"], "total": u["total"], "perTap": 1 + u["tap_lvl"],
        "energy": round(u["energy"], 2), "maxEnergy": max_energy(u), "regen": regen_rate(u),
        "tapLvl": u["tap_lvl"], "enLvl": u["en_lvl"], "regLvl": u["regen_lvl"],
        "tapCost": cost(u["tap_lvl"]), "enCost": cost(u["en_lvl"]), "regCost": cost(u["regen_lvl"]),
        "resetIn": reset_in(),
        "skin": u["skin"],
        "skins": [{"id": k, "name": n, "price": pr, "owned": k in u["skins"].split(",")} for k, n, pr in SKINS],
        "login": dict(login_info(u), step=LOGIN_STEP, days=LOGIN_DAYS),
        "tasks": [
            {"id": "sub", "title": "Подпишись на канал @wolfclik", "progress": 1 if u["sub"] else 0, "goal": 1,
             "reward": TASK_REWARD, "claimed": bool(u["sub"]), "once": True},
            {"id": "buy", "title": "Купи 3 любых улучшения", "progress": min(u["bought"], TASK_BUY_GOAL),
             "goal": TASK_BUY_GOAL, "reward": TASK_REWARD, "claimed": bool(u["c1"])},
            {"id": "earn", "title": "Заработай 1000 монет", "progress": min(u["earned"], TASK_EARN_GOAL),
             "goal": TASK_EARN_GOAL, "reward": TASK_REWARD, "claimed": bool(u["c2"])},
        ],
    }


def handle(req):
    tg_user = check_init(req.get("initData", ""))
    if not tg_user:
        return {"ok": False, "error": "Откройте игру через бота в Telegram"}
    action = req.get("action")
    sub_ok = is_subscribed(tg_user["id"]) if action == "claim" and req.get("task") == "sub" else None
    with LOCK:
        c = db()
        try:
            u = load(c, tg_user)
            if action == "tap":
                n = max(0, min(int(req.get("n", 0)), MAX_BATCH))
                allowed = min(n, int(u["energy"]))
                lucky = sum(1 for _ in range(allowed) if random.random() < LUCKY_CHANCE)
                gain = allowed * (1 + u["tap_lvl"]) + lucky * LUCKY_BONUS
                u["energy"] -= allowed
                u["coins"] += gain
                u["total"] += gain
                u["earned"] += gain
                save(c, u)
                return {"ok": True, "state": state(u), "lucky": lucky, "luckyBonus": LUCKY_BONUS}
            elif action == "buy":
                key = {"tap": "tap_lvl", "energy": "en_lvl", "regen": "regen_lvl"}.get(req.get("kind"))
                if key is None:
                    return {"ok": False, "error": "Неизвестное улучшение"}
                lvl = u[key]
                price = cost(lvl)
                if u["coins"] < price:
                    save(c, u)
                    return {"ok": False, "error": "Не хватает монет", "state": state(u)}
                u["coins"] -= price
                u[key] += 1
                u["bought"] += 1
            elif action == "claim":
                t = req.get("task")
                if t == "buy" and u["bought"] >= TASK_BUY_GOAL and not u["c1"]:
                    u["c1"] = 1
                elif t == "earn" and u["earned"] >= TASK_EARN_GOAL and not u["c2"]:
                    u["c2"] = 1
                elif t == "sub" and not u["sub"]:
                    if sub_ok is not True:
                        save(c, u)
                        msg = "Вы ещё не подписаны на канал" if sub_ok is False else "Не удалось проверить подписку, попробуйте позже"
                        return {"ok": False, "error": msg, "state": state(u)}
                    u["sub"] = 1
                else:
                    save(c, u)
                    return {"ok": False, "error": "Задание ещё не выполнено", "state": state(u)}
                u["coins"] += TASK_REWARD
                u["total"] += TASK_REWARD
            elif action == "login":
                info = login_info(u)
                if info["claimed"]:
                    save(c, u)
                    return {"ok": False, "error": "Бонус за сегодня уже получен", "state": state(u)}
                reward = LOGIN_STEP * info["day"]
                u["streak"] = info["day"]
                u["last_claim"] = day_key()
                u["coins"] += reward
                u["total"] += reward
            elif action == "skin":
                sid = req.get("id")
                if sid not in SKIN_PRICE:
                    return {"ok": False, "error": "Неизвестный скин"}
                owned = set(u["skins"].split(","))
                if sid not in owned:
                    if u["coins"] < SKIN_PRICE[sid]:
                        save(c, u)
                        return {"ok": False, "error": "Не хватает монет", "state": state(u)}
                    u["coins"] -= SKIN_PRICE[sid]
                    owned.add(sid)
                    u["skins"] = ",".join(sorted(owned))
                u["skin"] = sid
            elif action == "top":
                save(c, u)
                rows = c.execute("SELECT name,total FROM users ORDER BY total DESC LIMIT 20").fetchall()
                rank = c.execute("SELECT COUNT(*)+1 FROM users WHERE total>?", (u["total"],)).fetchone()[0]
                return {"ok": True, "state": state(u), "me": u["id"], "rank": rank,
                        "top": [{"name": r["name"], "total": r["total"]} for r in rows]}
            save(c, u)
            return {"ok": True, "state": state(u)}
        finally:
            c.close()


def application(environ, start_response):
    headers = [("Access-Control-Allow-Origin", "*"),
               ("Access-Control-Allow-Headers", "Content-Type"),
               ("Access-Control-Allow-Methods", "POST, GET, OPTIONS"),
               ("Content-Type", "application/json; charset=utf-8")]
    method = environ["REQUEST_METHOD"]
    if method == "OPTIONS":
        start_response("204 No Content", headers)
        return [b""]
    if method == "GET":
        start_response("200 OK", headers)
        return [json.dumps({"ok": True, "msg": "Wolf Clicker server OK"}).encode()]
    try:
        size = min(int(environ.get("CONTENT_LENGTH") or 0), 20000)
        req = json.loads(environ["wsgi.input"].read(size) or b"{}")
        res = handle(req)
    except Exception as e:
        res = {"ok": False, "error": "Ошибка сервера: " + str(e)}
    start_response("200 OK", headers)
    return [json.dumps(res, ensure_ascii=False).encode("utf-8")]


if __name__ == "__main__":
    from socketserver import ThreadingMixIn
    from wsgiref.simple_server import WSGIServer, make_server

    class Threaded(ThreadingMixIn, WSGIServer):
        daemon_threads = True

    port = int(os.environ.get("PORT", 8000))
    print("Сервер запущен на порту", port)
    make_server("0.0.0.0", port, application, server_class=Threaded).serve_forever()
